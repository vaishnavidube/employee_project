INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email, salary, designation) 
VALUES
  	('Mukesh', 'Yadav', 'myl16@gmail.com', 12000, 'ASE'),
  	('Shyam', 'pandet', 'shyam4@gmail.com', 2000, 'ATE'),
  	('Ravi', 'Kumar', 'ravikumar321@gmail.com', 15000, 'LEAD');
  	